﻿
' This file is used by Code Analysis to maintain SuppressMessage 
' attributes that are applied to this project.
' Project-level suppressions either have no target or are given 
' a specific target and scoped to a namespace, type, member, etc.

<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("스타일", "IDE1006:명명 스타일", Justification:="<보류 중>", Scope:="member", Target:="~M:WebView2Tester__vb.MainForm.pf_CoreWebView2InitializationCompleted(System.Object,Microsoft.Web.WebView2.Core.CoreWebView2InitializationCompletedEventArgs)")>
