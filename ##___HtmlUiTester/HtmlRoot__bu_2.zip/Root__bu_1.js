// import hfCountTask from "./js/hfCountTask";



const _ta1 = document.getElementById('ta1');

const _counter = new hfCountTask(10, 30, 3);
// console.log(
//     `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }`);
// _ta1.value +=
//     `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }\n`;


const _btns = document.querySelectorAll('button');



const __fn_click = (te) => {
    // const tct = te.currentTarget;
    // // console.log(tct);

    // if (tct.textContent === 'Prev') {
    //     if (_counter.prev()) {
    //         // console.log(
    //         //     `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }`);
    //         _ta1.value +=
    //             `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }\n`;
    //     }
    // }
    // else if (tct.textContent === 'Next') {
    //     if (_counter.next()) {
    //         // console.log(
    //         //     `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }`);
    //         _ta1.value +=
    //             `Start: ${ _counter.countStart }, End: ${ _counter.countEnd }, Current: ${ _counter.count }\n`;
    //     }
    // }
};

for (const btn of _btns) {
    btn.addEventListener('click', __fn_click);
}





const _dcView = document.getElementById('dcView');

_dcView.innerHTML = `<div style="box-sizing: border-box; margin-right: 0px; background-color: red; width: 100px; height: 100px;">xxx</div>`;




/*
const _ta1 = document.getElementById('ta1');

let tcp = 0;
const __fn_loop = () => {
    if ((tcp % 13) === 0) {
        _ta1.value = _ta1.value + 'xx';
    }
    tcp++;
    requestAnimationFrame(__fn_loop);
};
// __fn_loop();
*/


