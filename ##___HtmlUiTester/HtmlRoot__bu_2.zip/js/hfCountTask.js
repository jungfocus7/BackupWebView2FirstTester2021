class hfCountTask {

    #countStart = 0;
    #countEnd = 0;
    #count = 0;
    #plusValue = 0;

    constructor(countStart, countEnd, plusValue = 1) {
        this.#countStart = countStart;
        this.#countEnd = countEnd;
        this.#count = countStart;
        this.#plusValue = plusValue;
    }


    get countStart() {
        return this.#countStart;
    }

    get countEnd() {
        return this.#countEnd;
    }

    get count() {
        return this.#count;
    }

    get plusValue() {
        return this.#plusValue;
    }


    prev() {
        const tc = this.#count - this.#plusValue;
        if (tc < this.#countStart)
            return false;
        else {
            this.#count = tc;
            return true;
        }
    }

    next() {
        const tc = this.#count + this.#plusValue;
        if (tc > this.#countEnd)
            return false;
        else {
            this.#count = tc;
            return true;
        }
    }


    reset() {
        this.#count = this.#countStart;
    }





    // prev() {
    //     if (this.#count > this.#countStart) {
    //         const tc = this.#count - this.#plusValue;
    //         if (tc < this.#countStart)
    //             return false;
    //         else {
    //             this.#count = tc;
    //             return true;
    //         }
    //     }
    //     else
    //         return false;
    // }

    // next() {
    //     if (this.#count < this.#countEnd) {
    //         const tc = this.#count + this.#plusValue;
    //         if (tc > this.#countEnd)
    //             return false;
    //         else {
    //             this.#count = tc;
    //             return true;
    //         }
    //     }
    //     else
    //         return false;
    // }



    // isLast() {
    //     if (this.#count < this.#countEnd) {
    //         const tc = this.#count + this.#plusValue;
    //         if (tc > this.#countEnd)
    //             return true;
    //         else {
    //             this.#count = tc;
    //             return false;
    //         }
    //     }
    //     else
    //         return true;
    // }


}


// export default hfCountTask;
